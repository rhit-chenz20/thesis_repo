// For setting up the Git commit SHA-1 as a global
// This is used when building under Xcode

extern const char g_GIT_SHA1[];

const char g_GIT_SHA1[] = "unknown (not defined under Xcode)";
