// For setting up the Git commit SHA-1 as a global
// See ../cmake/_README.txt

extern const char g_GIT_SHA1[];
